#!/usr/bin/env python3
"""Live ROS/GPIO/UART adapter for the testable full-run controller."""
from __future__ import annotations

import argparse
from dataclasses import asdict
import json
import math
from pathlib import Path
import queue
import secrets
import signal
import sys
import time
import traceback

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))
from jetson.amr_core.full_run import ControlStatus, FullRunConfig, FullRunController
from jetson.amr_core.full_run_log import FlightRecorder
from jetson.amr_core.full_run_diagnostics import request_auto_bundle
from jetson.amr_core.full_run_ultrasonic import UltrasonicWorker
from jetson.amr_core.full_run_legacy import LegacyControlAdapter
from jetson.amr_core.full_run_user_stop import read_stop_request
from jetson.amr_core.reactive_avoidance import wrap_angle


def parse_scan(message, config):
    if (not all(math.isfinite(v) for v in (message.angle_min, message.angle_increment,
                                          message.range_min, message.range_max))
            or message.angle_increment == 0 or not 0 <= message.range_min < message.range_max):
        raise ValueError("Invalid LaserScan geometry")
    points, front, covered = [], [], {"left": 0, "right": 0}
    yaw = math.radians(config.lidar_yaw_deg)
    for index, distance in enumerate(message.ranges):
        angle = wrap_angle(message.angle_min + index * message.angle_increment + yaw)
        valid = math.isfinite(distance) and message.range_min <= distance <= message.range_max and distance > 0
        clear = distance == math.inf
        if not valid and not clear:
            continue
        if math.radians(70) <= angle <= math.radians(110):
            covered["left"] += 1
        if -math.radians(110) <= angle <= -math.radians(70):
            covered["right"] += 1
        if valid:
            x = config.lidar_x_m + distance * math.cos(angle)
            y = config.lidar_y_m + distance * math.sin(angle)
            robot_angle, robot_range = math.atan2(y, x), math.hypot(x, y)
            points.append((robot_angle, robot_range))
            if abs(robot_angle) <= math.radians(15):
                front.append(robot_range)
        elif abs(angle) <= math.radians(15):
            front.append(message.range_max)
    if not all(covered.values()) or not front:
        raise ValueError(f"Missing valid front/side scan coverage: {covered}")
    return sorted(points), min(front)


def make_node(config, core, recorder):
    from rclpy.node import Node
    from rclpy.qos import qos_profile_sensor_data
    from sensor_msgs.msg import LaserScan
    from std_msgs.msg import String

    class FullRunNode(Node):
        def __init__(self):
            super().__init__("amr_full_run")
            self.create_subscription(String, "/yolo/detections", self.camera, 10)
            self.create_subscription(LaserScan, "/scan", self.scan, qos_profile_sensor_data)

        def camera(self, message):
            now = time.monotonic()
            recorder.emit("yolo_raw", payload=message.data)
            try:
                detections = json.loads(message.data)
                if not isinstance(detections, list) or any(not isinstance(d, dict) for d in detections):
                    raise ValueError("Expected a list of detection objects")
                core.update_camera(detections, now)
            except (ValueError, TypeError, KeyError) as exc:
                core.camera_stamp = None
                recorder.emit("yolo_invalid", error=str(exc))

        def scan(self, message):
            now = time.monotonic()
            recorder.emit("scan_raw", frame_id=message.header.frame_id,
                          source_stamp={"sec": message.header.stamp.sec, "nanosec": message.header.stamp.nanosec},
                          angle_min=message.angle_min, angle_increment=message.angle_increment,
                          range_min=message.range_min, range_max=message.range_max, ranges=list(message.ranges))
            try:
                points, front = parse_scan(message, config)
                core.update_scan(points, front, now)
            except (ValueError, TypeError) as exc:
                core.scan_stamp = None
                recorder.emit("scan_invalid", error=str(exc))
    return FullRunNode()


def main(arguments=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(PROJECT / "config/full_run.json"))
    parser.add_argument("--port", default="/dev/ttyTHS1")
    parser.add_argument("--status-port", default="/dev/ttyTHS2")
    parser.add_argument("--baudrate", type=int, default=115200)
    parser.add_argument("--mcu-protocol", choices=("legacy", "ctrl"), default="legacy",
                        help="Default legacy uses existing $CMD/$STATUS; no firmware update")
    parser.add_argument("--user-stop-file")
    parser.add_argument("--log-dir", required=True)
    parser.add_argument("--supervisor-pid", type=int)
    parser.add_argument("--supervisor-start-ticks")
    parser.add_argument("--check-config", action="store_true")
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args(arguments)
    config = FullRunConfig.read(args.config)
    if args.check_config:
        print(json.dumps({"configuration": asdict(config), "mcu_protocol": args.mcu_protocol,
                          "expected_side_range_m": config.expected_side_range_m,
                          "rear_clearance_m": config.rear_clearance_m}, indent=2))
        return 0
    recorder = FlightRecorder(args.log_dir, config.log_max_bytes, config.log_backup_count)
    recorder.emit("configuration", config=asdict(config), port=args.port, status_port=args.status_port,
                  mcu_protocol=args.mcu_protocol,
                  argv=sys.argv, python=sys.version, expected_side_range_m=config.expected_side_range_m,
                  rear_clearance_m=config.rear_clearance_m)
    core = FullRunController(config, secrets.randbelow(0x7ffffffe) + 1, time.monotonic(), recorder.emit,
                             mcu_protocol=args.mcu_protocol)
    legacy = LegacyControlAdapter(core.session, config.maximum_rpm, recorder.emit) if args.mcu_protocol == "legacy" else None
    command_uart = status_uart = worker = node = None
    ros_initialized = False
    interrupted = False
    bundle_requested = False
    failed = False
    last_stop_request = None
    instant_stop_pending = False

    def interrupt(signum, _frame):
        nonlocal interrupted
        interrupted = True
        recorder.emit("signal", number=signum)

    signal.signal(signal.SIGINT, interrupt)
    signal.signal(signal.SIGTERM, interrupt)
    try:
        import serial
        import rclpy
        import Jetson.GPIO as GPIO
        command_uart = serial.Serial(args.port, args.baudrate, timeout=0, write_timeout=0.15, exclusive=True)
        status_uart = command_uart if args.status_port == args.port else serial.Serial(
            args.status_port, args.baudrate, timeout=0, write_timeout=0.15, exclusive=True)
        status_uart.reset_input_buffer()
        rclpy.init()
        ros_initialized = True
        node = make_node(config, core, recorder)
        worker = UltrasonicWorker(GPIO, config, recorder.emit)
        buffer = bytearray()
        last_handshake = -math.inf
        last_snapshot = -math.inf
        last_command_s = time.monotonic()
        recorder.emit("handshake", session=core.session,
                      mcu_protocol=args.mcu_protocol,
                      message=("Waiting for existing $STATUS. No firmware update or $FULL handshake."
                               if legacy else "Waiting for matching $CTRL v1 (optional extended firmware)."))
        # Imports and GPIO setup can legitimately take seconds before the
        # heartbeat begins. Only running-loop gaps count as scheduler faults.
        core.last_tick = time.monotonic()
        while rclpy.ok() and not interrupted:
            cycle_started = time.monotonic()
            if args.supervisor_pid is not None:
                try:
                    stat = Path(f"/proc/{args.supervisor_pid}/stat").read_text()
                    start_ticks = stat.rsplit(")", 1)[1].split()[19]
                except (OSError, IndexError):
                    start_ticks = None
                if start_ticks != args.supervisor_start_ticks:
                    recorder.emit("exception", reason="launcher_disappeared_or_PID_reused")
                    return 1
            rclpy.spin_once(node, timeout_sec=0)
            incoming = status_uart.read(min(status_uart.in_waiting, 4096))
            if incoming:
                recorder.emit("uart_rx_chunk", hex=incoming.hex(), text=incoming.decode("ascii", errors="replace"))
                buffer.extend(incoming)
            if len(buffer) > 8192:
                recorder.emit("uart_overflow", bytes=len(buffer))
                buffer.clear()
                core.status_stamp = None
            while b"\n" in buffer:
                line, _, rest = buffer.partition(b"\n")
                buffer = bytearray(rest)
                decoded = line.rstrip(b"\r").decode("ascii", errors="replace")
                recorder.emit("uart_line", line=decoded)
                if legacy and decoded.startswith("$STATUS"):
                    try:
                        core.update_status(legacy.decode(decoded, time.monotonic(),
                                                        allow_controls=core.state != "STARTUP"), time.monotonic())
                    except ValueError as exc:
                        core.status_stamp = None
                        recorder.emit("STATUS_invalid", error=str(exc), line=decoded)
                elif not legacy and decoded.startswith("$CTRL"):
                    try:
                        core.update_status(ControlStatus.decode(decoded), time.monotonic())
                    except ValueError as exc:
                        core.status_stamp = None
                        recorder.emit("CTRL_invalid", error=str(exc), line=decoded)
                elif not legacy and decoded.startswith("$STATUS") and core.status is None:
                    recorder.emit("legacy_firmware", instruction="Set MCU_PROTOCOL=legacy to use existing firmware without flashing")
            while True:
                try:
                    core.update_side(worker.results.get_nowait())
                except queue.Empty:
                    break
            now = time.monotonic()
            if not legacy and core.status is None and now - last_handshake >= 0.5:
                payload = f"$FULL,{core.session}\r\n".encode("ascii")
                command_uart.write(payload)
                recorder.emit("uart_tx", kind="handshake", text=payload.decode("ascii"))
                last_handshake = now
            if args.user_stop_file and args.supervisor_pid is not None:
                try:
                    request = read_stop_request(args.user_stop_file, args.supervisor_pid,
                                                args.supervisor_start_ticks, last_stop_request)
                    if request:
                        last_stop_request = request["request_id"]
                        recorder.emit("user_instant_stop_request", request=request)
                        if core.state == "STARTUP":
                            recorder.emit("user_instant_stop_ignored", reason="startup is already stationary")
                        elif core.state != "FAULT_STOP":
                            if legacy:
                                legacy.request_instant_stop()
                            else:
                                instant_stop_pending = True
                            # Consume any UP already received in this cycle,
                            # even if we were still READY/already PAUSED.
                            core.change("PAUSED", "user_instant_stop_terminal")
                except (OSError, ValueError) as exc:
                    core.fault(f"user_stop_request_IO_or_format:{exc}")
                    recorder.emit("exception", context="user_stop_request", error=str(exc))
            command = core.tick(now)
            # Preflight can never issue a nonzero command, even if UP is pressed.
            if args.preflight_only:
                command = (0, 0)
            payload = f"$CMD,{command[0]},{command[1]},{int(instant_stop_pending)}\r\n".encode("ascii")
            count = command_uart.write(payload)
            if count != len(payload):
                raise IOError(f"Short UART write: {count}/{len(payload)}")
            instant_stop_pending = False
            recorder.emit("uart_tx", kind="command", text=payload.decode("ascii"),
                          heartbeat_gap_s=now - last_command_s, state=core.state, phase=core.phase)
            last_command_s = now
            worker.inside = core.inside if core.phase in ("BASELINE", "PASS", "REAR_CLEARANCE") else None
            if now - last_snapshot >= 0.10:
                snapshot = core.snapshot(now)
                if legacy:
                    snapshot["legacy"] = legacy.snapshot()
                recorder.emit("snapshot", **snapshot)
                last_snapshot = now
            if core.state == "FAULT_STOP" and not bundle_requested:
                # Zero RPM was already sent above. The launcher performs
                # compression in a separate process, keeping this heartbeat
                # loop responsive even with hundreds of MB of sensor logs.
                bundle_requested = True
                try:
                    if request_auto_bundle(args.log_dir, core.fault_reason):
                        recorder.emit("auto_bundle_requested", reason=core.fault_reason)
                except OSError as exc:
                    print(f"[BUNDLE FAIL] Cannot request diagnostics: {exc}", file=sys.stderr, flush=True)
            if args.preflight_only and core.preflight_ready:
                recorder.emit("ready", mcu_protocol=args.mcu_protocol,
                              message="Preflight passed: fresh camera/LiDAR/MCU status/GPIO, zero motion only")
                return 0
            if args.preflight_only and core.state == "FAULT_STOP":
                return 1
            time.sleep(max(0, 0.02 - (time.monotonic() - cycle_started)))
        return 0
    except Exception:
        failed = True
        recorder.emit("exception", traceback=traceback.format_exc(), snapshot=core.snapshot(time.monotonic()))
        return 1
    finally:
        # Stop the actuator first. GPIO teardown/ROS shutdown may take time.
        if command_uart is not None:
            try:
                for _ in range(3):
                    command_uart.write(b"$CMD,0,0,1\r\n")
                    time.sleep(0.02)
                recorder.emit("shutdown", reason="stop_and_brake_sent", snapshot=core.snapshot(time.monotonic()))
            except Exception:
                failed = True
                recorder.emit("exception", context="shutdown_stop", traceback=traceback.format_exc())
        for name, cleanup in (("gpio", worker.close if worker else None),
                              ("ROS_node", node.destroy_node if node else None),
                              ("status_UART", status_uart.close if status_uart and status_uart is not command_uart else None),
                              ("command_UART", command_uart.close if command_uart else None)):
            if cleanup:
                try:
                    cleanup()
                except Exception:
                    failed = True
                    recorder.emit("exception", context=name, traceback=traceback.format_exc())
        if ros_initialized:
            try:
                rclpy.shutdown()
            except Exception:
                failed = True
                recorder.emit("exception", context="ROS_shutdown", traceback=traceback.format_exc())
        if failed:
            try:
                request_auto_bundle(args.log_dir, "controller_exception_or_cleanup_failure")
            except OSError as exc:
                print(f"[BUNDLE FAIL] Cannot request diagnostics: {exc}", file=sys.stderr, flush=True)
        recorder.close()


if __name__ == "__main__":
    raise SystemExit(main())
